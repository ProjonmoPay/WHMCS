<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

function projonmopay_MetaData()
{
    return array(
        'DisplayName' => 'projonmopay',
        'APIVersion' => '1.0',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}


function projonmopay_link($params)
{
    $host_config = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    $host_config = pathinfo($host_config, PATHINFO_FILENAME);

    if (isset($_POST['pay'])) {

        $response = projonmopay_payment_url($params);
        if ($response->status && isset($response->payment_url)) {
            // Return the payment form that redirects to the payment URL
            return '<form action="' . $response->payment_url . '" method="GET">
                        <input class="btn btn-primary" type="submit" value="' . $params['langpaynow'] . '" />
                    </form>';
        } else {
            return $response->message;
        }
    }

    // For viewinvoice, show the payment button
    if ($host_config == "viewinvoice") {
        return '<form action="" method="POST">
                    <input class="btn btn-primary" name="pay" type="submit" value="' . $params['langpaynow'] . '" />
                </form>';
    } else {
        // For other pages, show the payment button with a direct URL
        $response = projonmopay_payment_url($params);
        if ($response->status && isset($response->payment_url)) {
            return '<form action="' . $response->payment_url . '" method="GET">
                        <input class="btn btn-primary" type="submit" value="' . $params['langpaynow'] . '" />
                    </form>';
        } else {
            return $response->message;
        }
    }
}

function projonmopay_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'projonmopay',
        ),
        'apiKey' => array(
            'FriendlyName' => 'API Key',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '',
            'Description' => 'Enter Your Api Key',
        ),
        'currency_rate' => array(
            'FriendlyName' => 'Currency Rate',
            'Type' => 'text',
            'Size' => '150',
            'Default' => '85',
            'Description' => 'Enter Dollar Rate',
        )
    );
}

function projonmopay_payment_url($params)
{
    $cus_name = $params['clientdetails']['firstname'] . " " . $params['clientdetails']['lastname'];
    $cus_email = $params['clientdetails']['email'];

    $apikey = $params['apiKey'];
    $currency_rate = $params['currency_rate'];

    $invoiceId = $params['invoiceid'];

    // Convert amount if currency is USD
    if ($params['currency'] == "USD") {
        $amount = $params['amount'] * $currency_rate;
    } else {
        $amount = $params['amount'];
    }

    $hostname = $params['hostName'];

    // Get system URL dynamically
    $systemUrl = ((isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') ? "https://" : "http://") . $_SERVER['HTTP_HOST'];

    // Webhook, success, and cancel URLs
    $webhook_url = $systemUrl . '/modules/gateways/callback/projonmopay.php?api=' . $apikey . '&invoice=' . $invoiceId;
    $success_url = $systemUrl . '/viewinvoice.php?id=' . $invoiceId;
    $cancel_url = $systemUrl . '/viewinvoice.php?id=' . $invoiceId;


    $data = array(
        "cus_name" => $cus_name,
        "cus_email" => $cus_email,
        "amount" => $amount,
        "webhook_url" => $webhook_url,
        "success_url" => $success_url,
        "cancel_url" => $cancel_url,
    );

    // API headers
    $headers = array(
        'Content-Type: application/json',
        'API-KEY: ' . $apikey,
    );


    $curl = curl_init();
    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://secure.projonmopay.com/api/payment/create',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($data),
        CURLOPT_HTTPHEADER => $headers,
    ));

    $response = curl_exec($curl);
    curl_close($curl);

    // Decode response
    $res = json_decode($response, true);

    // Check for successful response and return result
    if (isset($res['status']) && $res['status'] && isset($res['payment_url'])) {
        return (object) [
            'status' => true,
            'payment_url' => $res['payment_url']
        ];
    } else {
        return (object) [
            'status' => false,
            'message' => $res['message'] ?? 'Payment failed'
        ];
    }
}
